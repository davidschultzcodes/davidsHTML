//David Schultz
//CS 376
//PlayfairCipher
//substitute letter is X


//to run, press run and use terminal for output
//  tested with cipher text: DMAAQVNEAC and key: PLAYFAIR EXAMPLE 
//  and output is: HELLOWORLD

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PlayfairCipher {
    private static final char PAD_CHAR = 'X';
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the cipher text:");
        String cipherText = scanner.nextLine();

        System.out.println("Enter key:");
        String key = scanner.nextLine();

        String decryptedMessage = decrypt(cipherText, key);
        System.out.println("Decryption: " + decryptedMessage);

        scanner.close();
    }

    //=========================================================

    public static String decrypt(String cipher, String key) {
        char[][] keySquare = generateKeySquare(key);
        List<String> pairs = generatePairs(cipher);
        StringBuilder message = new StringBuilder();

        for (String pair : pairs) {
            char first = pair.charAt(0);
            char second = pair.charAt(1);

            int[] pos1 = findPosition(keySquare, first);
            int[] pos2 = findPosition(keySquare, second);

            StringBuilder newPair = new StringBuilder();

            if (pos1[0] == pos2[0]) {
                newPair.append(keySquare[pos1[0]][(pos1[1] - 1 + 5) % 5]);
                newPair.append(keySquare[pos2[0]][(pos2[1] - 1 + 5) % 5]);
            } else if (pos1[1] == pos2[1]) {
                newPair.append(keySquare[(pos1[0] - 1 + 5) % 5][pos1[1]]);
                newPair.append(keySquare[(pos2[0] - 1 + 5) % 5][pos2[1]]);
            } else {
                newPair.append(keySquare[pos1[0]][pos2[1]]);
                newPair.append(keySquare[pos2[0]][pos1[1]]);
            }

            message.append(newPair);
        }

        return message.toString();
    }

    //=========================================================

    private static char[][] generateKeySquare(String key) {
        key = key.toUpperCase().replaceAll("[^A-Z]", "").replace("J", "I");
        String keyWithoutDuplicates = removeDuplicates(key);
        char[][] keySquare = new char[5][5];
        String alphabet = "ABCDEFGHIKLMNOPQRSTUVWXYZ";
        int i = 0, j = 0;

        for (char letter : keyWithoutDuplicates.toCharArray()) {
            keySquare[i][j] = letter;
            j++;
            if (j == 5) {
                i++;
                j = 0;
            }
        }

        for (char letter : alphabet.toCharArray()) {
            if (!keyWithoutDuplicates.contains(String.valueOf(letter))) {
                keySquare[i][j] = letter;
                j++;
                if (j == 5) {
                    i++;
                    j = 0;
                }
            }
        }

        return keySquare;
    }

    //=========================================================

    private static String removeDuplicates(String str) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {
            if (!result.toString().contains(String.valueOf(str.charAt(i)))) {
                result.append(str.charAt(i));
            }
        }
        return result.toString();
    }

    //=========================================================

    private static List<String> generatePairs(String message) {
        message = message.toUpperCase().replaceAll("[^A-Z]", "").replace("J", "I");
        if (message.length() % 2 != 0) {
            message += PAD_CHAR;
        }

        List<String> pairs = new ArrayList<>();
        for (int i = 0; i < message.length(); i += 2) {
            pairs.add(message.substring(i, i + 2));
        }

        return pairs;
    }

    //=========================================================

    private static int[] findPosition(char[][] keySquare, char letter) {
        int[] position = new int[2];

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (keySquare[i][j] == letter) {
                    position[0] = i;
                    position[1] = j;
                    return position;
                }
            }
        }

        return null;
    }
}
